"""Edge-Adaptive Recursive Bellman/Riccati Filter for WCE Frame Restoration.

Implements Stage I of the BF-VVT-SMCNN-DRA framework:
- State-space scanline formulation
- Position-dependent edge-stopping process noise variance Q_t
- Vectorized recursive Bellman optimization updates (Equations 6-10 in manuscript)
- Steady-state Riccati algebraic equation solver (Theorem 1 in manuscript)
"""

import numpy as np
import math


def solve_steady_state_riccati(Q: float, R: float) -> tuple[float, float, float]:
    """Computes the unique positive steady-state Riccati solution and gain.
    
    P_inf^2 - Q * P_inf - Q * R = 0
    P_inf = (Q + sqrt(Q^2 + 4*Q*R)) / 2
    K_inf = P_inf / (P_inf + R)
    rho = (1 - K_inf)^2 (contraction factor)
    """
    P_inf = (Q + math.sqrt(Q**2 + 4.0 * Q * R)) / 2.0
    K_inf = P_inf / (P_inf + R)
    rho = (1.0 - K_inf) ** 2
    return P_inf, K_inf, rho


class EdgeAdaptiveBellmanFilter:
    """Separable 2D Edge-Adaptive Recursive Bellman Filter for color endoscopic imagery."""

    def __init__(
        self,
        Q0: float = 0.006,
        R: float = 0.0025,
        sigma_s: float = 0.30,
        epsilon: float = 1e-5,
        bidirectional: bool = True,
    ):
        self.Q0 = float(Q0)
        self.R = float(R)
        self.sigma_s = float(sigma_s)
        self.epsilon = float(epsilon)
        self.bidirectional = bidirectional
        self.P_inf, self.K_inf, self.rho = solve_steady_state_riccati(self.Q0, self.R)

    def _filter_scanlines_vectorized(self, matrix: np.ndarray) -> np.ndarray:
        """Vectorized 1D recursive filtering across all rows simultaneously (H, W)."""
        H, W = matrix.shape
        x_fwd = np.zeros((H, W), dtype=np.float32)
        P_fwd = np.zeros((H, W), dtype=np.float32)

        x_fwd[:, 0] = matrix[:, 0]
        P_fwd[:, 0] = self.P_inf

        for t in range(1, W):
            diff = np.abs(matrix[:, t] - matrix[:, t - 1])
            Q_t = self.Q0 * np.exp(-diff / self.sigma_s) + self.epsilon
            P_pred = P_fwd[:, t - 1] + Q_t
            K_t = P_pred / (P_pred + self.R)
            x_pred = x_fwd[:, t - 1]
            x_fwd[:, t] = x_pred + K_t * (matrix[:, t] - x_pred)
            P_fwd[:, t] = (1.0 - K_t) * P_pred

        if not self.bidirectional:
            return x_fwd

        # Backward pass
        x_bwd = np.zeros((H, W), dtype=np.float32)
        P_bwd = np.zeros((H, W), dtype=np.float32)

        x_bwd[:, -1] = matrix[:, -1]
        P_bwd[:, -1] = self.P_inf

        for t in range(W - 2, -1, -1):
            diff = np.abs(matrix[:, t] - matrix[:, t + 1])
            Q_t = self.Q0 * np.exp(-diff / self.sigma_s) + self.epsilon
            P_pred = P_bwd[:, t + 1] + Q_t
            K_t = P_pred / (P_pred + self.R)
            x_pred = x_bwd[:, t + 1]
            x_bwd[:, t] = x_pred + K_t * (matrix[:, t] - x_pred)
            P_bwd[:, t] = (1.0 - K_t) * P_pred

        # Variance-weighted fusion
        inv_P_fwd = 1.0 / np.maximum(P_fwd, 1e-8)
        inv_P_bwd = 1.0 / np.maximum(P_bwd, 1e-8)
        smoothed = (x_fwd * inv_P_fwd + x_bwd * inv_P_bwd) / (inv_P_fwd + inv_P_bwd)
        return smoothed

    def filter_channel(self, channel: np.ndarray) -> np.ndarray:
        """Separable 2D filtering on a single 2D channel: Horizontal then Vertical."""
        # Pass 1: Horizontal scanlines
        h_filtered = self._filter_scanlines_vectorized(channel)

        # Pass 2: Vertical scanlines (via transpose)
        v_filtered = self._filter_scanlines_vectorized(h_filtered.T).T

        return np.clip(v_filtered, 0.0, 1.0)

    def __call__(self, img: np.ndarray) -> np.ndarray:
        img = np.asarray(img, dtype=np.float32)
        if img.max() > 1.0:
            img = img / 255.0

        if img.ndim == 2:
            return self.filter_channel(img)
        elif img.ndim == 3:
            filtered = np.empty_like(img, dtype=np.float32)
            for c in range(img.shape[2]):
                filtered[:, :, c] = self.filter_channel(img[:, :, c])
            return filtered
        else:
            raise ValueError(f"Expected 2D or 3D array, got shape {img.shape}")
