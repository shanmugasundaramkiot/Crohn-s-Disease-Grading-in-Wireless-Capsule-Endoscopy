"""Baseline Image Filtering Implementations for Benchmarking."""

import cv2
import numpy as np


class BilateralFilter:
    """Standard Bilateral Filter baseline."""

    def __init__(self, d: int = 9, sigma_color: float = 75.0, sigma_space: float = 75.0):
        self.d = d
        self.sigma_color = sigma_color
        self.sigma_space = sigma_space

    def __call__(self, img: np.ndarray) -> np.ndarray:
        scaled = (np.clip(img, 0.0, 1.0) * 255.0).astype(np.uint8)
        filtered = cv2.bilateralFilter(scaled, self.d, self.sigma_color, self.sigma_space)
        return filtered.astype(np.float32) / 255.0


class GaussianFilter:
    """Standard Gaussian Blur baseline."""

    def __init__(self, ksize: int = 5, sigma: float = 1.5):
        self.ksize = ksize
        self.sigma = sigma

    def __call__(self, img: np.ndarray) -> np.ndarray:
        scaled = (np.clip(img, 0.0, 1.0) * 255.0).astype(np.uint8)
        filtered = cv2.GaussianBlur(scaled, (self.ksize, self.ksize), self.sigma)
        return filtered.astype(np.float32) / 255.0


class MedianFilter:
    """Standard Median Filter baseline."""

    def __init__(self, ksize: int = 5):
        self.ksize = ksize

    def __call__(self, img: np.ndarray) -> np.ndarray:
        scaled = (np.clip(img, 0.0, 1.0) * 255.0).astype(np.uint8)
        filtered = cv2.medianBlur(scaled, self.ksize)
        return filtered.astype(np.float32) / 255.0
