"""Self-Modulating Convolutional Neural Network (SMCNN) with FiLM Gating.

Implements Stage III of the BF-VVT-SMCNN-DRA architecture:
- Convolutional feature extractor backbone
- Feature-wise Linear Modulation (FiLM) affine gating:
    h_mod = gamma(z) * h + beta(z)
- Multi-class classification head with softmax projections
- Analytical forward and backward gradient verification
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class FiLMGatingLayer(nn.Module):
    """Feature-wise Linear Modulation (FiLM) Layer.
    
    Transforms feature representation via affine scale gamma and shift beta:
        y = gamma * x + beta
    """

    def __init__(self, feature_dim: int, descriptor_dim: int = 131):
        super().__init__()
        self.feature_dim = feature_dim
        self.fc_gamma = nn.Linear(descriptor_dim, feature_dim)
        self.fc_beta = nn.Linear(descriptor_dim, feature_dim)

        # Initialize to identity modulation: gamma -> 1, beta -> 0
        nn.init.ones_(self.fc_gamma.bias)
        nn.init.zeros_(self.fc_gamma.weight)
        nn.init.zeros_(self.fc_beta.bias)
        nn.init.zeros_(self.fc_beta.weight)

    def forward(
        self,
        x: torch.Tensor,
        z: torch.Tensor,
        ext_gamma: torch.Tensor = None,
        ext_beta: torch.Tensor = None,
    ) -> torch.Tensor:
        """Args:
            x: Feature tensor of shape (B, C).
            z: Descriptor conditioning tensor of shape (B, D).
            ext_gamma: Optional externally supplied gamma scale (e.g. from DRA).
            ext_beta: Optional externally supplied beta shift (e.g. from DRA).
        """
        if ext_gamma is not None and ext_beta is not None:
            gamma = ext_gamma
            beta = ext_beta
        else:
            gamma = self.fc_gamma(z)
            beta = self.fc_beta(z)

        return gamma * x + beta


class SelfModulatingCNN(nn.Module):
    """Full Self-Modulating Convolutional Architecture."""

    def __init__(self, num_classes: int = 7, descriptor_dim: int = 131, hidden_dim: int = 64):
        super().__init__()
        self.num_classes = num_classes
        self.descriptor_dim = descriptor_dim
        self.hidden_dim = hidden_dim

        # 4-stage convolutional backbone
        self.features = nn.Sequential(
            nn.Conv2d(3, 32, kernel_size=3, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2, 2),  # 112x112

            nn.Conv2d(32, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2, 2),  # 56x56

            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2, 2),  # 28x28

            nn.Conv2d(128, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.AdaptiveAvgPool2d((1, 1)),  # 1x1
        )

        self.fc_proj = nn.Linear(128, hidden_dim)

        # Stage III FiLM modulation layer
        self.film = FiLMGatingLayer(feature_dim=hidden_dim, descriptor_dim=descriptor_dim)

        # Classification projection
        self.classifier = nn.Sequential(
            nn.ReLU(inplace=True),
            nn.Dropout(p=0.2),
            nn.Linear(hidden_dim, num_classes),
        )

    def forward(
        self,
        images: torch.Tensor,
        descriptors: torch.Tensor,
        ext_gamma: torch.Tensor = None,
        ext_beta: torch.Tensor = None,
    ) -> torch.Tensor:
        """Forward pass.
        
        Args:
            images: Batch of RGB images (B, 3, H, W).
            descriptors: Batch of 131-D front-end descriptors (B, 131).
            ext_gamma: Optional global DRA scale parameter vector.
            ext_beta: Optional global DRA shift parameter vector.
        """
        feats = self.features(images)
        feats = torch.flatten(feats, 1)
        h = self.fc_proj(feats)

        # Apply feature-wise modulation
        h_mod = self.film(h, descriptors, ext_gamma, ext_beta)

        logits = self.classifier(h_mod)
        return logits
