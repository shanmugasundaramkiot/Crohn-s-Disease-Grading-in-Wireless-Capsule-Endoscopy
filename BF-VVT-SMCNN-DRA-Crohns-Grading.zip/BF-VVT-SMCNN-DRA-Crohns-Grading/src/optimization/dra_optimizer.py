"""Divine Religions Algorithm (DRA) for Global Modulation Hyperparameter Tuning.

Implements Stage IV of the BF-VVT-SMCNN-DRA framework:
- Social competition model of multiple religious belief systems
- Leaders and follower consensus updates
- Stochastic miracle operator (cross-cluster belief coordinate exchange)
- Elitist archive preservation ensuring monotonic convergence
"""

import numpy as np
import torch
import torch.nn as nn
from typing import Callable, Tuple


class DivineReligionsAlgorithm:
    def __init__(
        self,
        dim: int = 131 * 2,  # 131 gamma + 131 beta = 262 parameters
        num_religions: int = 6,
        followers_per_religion: int = 6,
        max_iterations: int = 45,
        miracle_rate: float = 0.45,
        gamma_bounds: Tuple[float, float] = (0.6, 1.4),
        beta_bounds: Tuple[float, float] = (-0.4, 0.4),
        random_seed: int = 42,
    ):
        self.dim = dim
        self.num_religions = num_religions
        self.followers_per_religion = followers_per_religion
        self.total_pop = num_religions * followers_per_religion  # 36 agents
        self.max_iterations = max_iterations
        self.miracle_rate = miracle_rate
        self.gamma_min, self.gamma_max = gamma_bounds
        self.beta_min, self.beta_max = beta_bounds
        self.rng = np.random.default_rng(random_seed)

        # Upper and lower bounds for all 262 dimensions
        self.lb = np.array([self.gamma_min] * (dim // 2) + [self.beta_min] * (dim // 2), dtype=np.float32)
        self.ub = np.array([self.gamma_max] * (dim // 2) + [self.beta_max] * (dim // 2), dtype=np.float32)

    def optimize(self, fitness_func: Callable[[np.ndarray], float]) -> Tuple[np.ndarray, float, list]:
        """Executes the DRA metaheuristic optimization.
        
        Args:
            fitness_func: Objective function returning a scalar fitness score (higher is better).
        Returns:
            best_position: Optimal 262-D parameter vector (gamma, beta).
            best_fitness: Highest fitness score achieved.
            convergence_curve: History of best fitness values per iteration.
        """
        # Initialize population across religions: shape (num_religions, followers_per_religion, dim)
        population = self.rng.uniform(
            self.lb, self.ub, size=(self.num_religions, self.followers_per_religion, self.dim)
        ).astype(np.float32)

        # Ensure one agent starts at the nominal identity setting: gamma = 1, beta = 0
        nominal = np.array([1.0] * (self.dim // 2) + [0.0] * (self.dim // 2), dtype=np.float32)
        population[0, 0] = nominal

        fitness = np.zeros((self.num_religions, self.followers_per_religion), dtype=np.float32)

        for r in range(self.num_religions):
            for i in range(self.followers_per_religion):
                fitness[r, i] = fitness_func(population[r, i])

        # Identify initial religious leaders and global leader
        leader_indices = [np.argmax(fitness[r]) for r in range(self.num_religions)]
        leaders = np.array([population[r, leader_indices[r]] for r in range(self.num_religions)])
        leader_fitness = np.array([fitness[r, leader_indices[r]] for r in range(self.num_religions)])

        global_best_idx = np.argmax(leader_fitness)
        global_best_pos = leaders[global_best_idx].copy()
        global_best_fit = leader_fitness[global_best_idx]

        convergence_curve = [float(global_best_fit)]

        # Iteration loop
        for t in range(self.max_iterations):
            for r in range(self.num_religions):
                for i in range(self.followers_per_religion):
                    if i == leader_indices[r]:
                        continue  # Leader retains position

                    r1 = self.rng.uniform(0.0, 1.0, size=self.dim)
                    r2 = self.rng.uniform(0.0, 1.0, size=self.dim)

                    # Consensus update towards religious leader and global best
                    step = (
                        r1 * (leaders[r] - population[r, i])
                        + r2 * (global_best_pos - population[r, i])
                    )
                    new_pos = np.clip(population[r, i] + step, self.lb, self.ub)
                    new_fit = fitness_func(new_pos)

                    if new_fit > fitness[r, i]:
                        population[r, i] = new_pos
                        fitness[r, i] = new_fit

                # Re-evaluate religious leader
                leader_indices[r] = np.argmax(fitness[r])
                leaders[r] = population[r, leader_indices[r]]
                leader_fitness[r] = fitness[r, leader_indices[r]]

            # Miracle Operator (Inter-religion exchange)
            for r in range(self.num_religions):
                if self.rng.uniform() < self.miracle_rate:
                    target_r = self.rng.choice([x for x in range(self.num_religions) if x != r])
                    # Cross-breed leader coordinates
                    cross_mask = self.rng.uniform(0.0, 1.0, size=self.dim) < 0.5
                    miracle_pos = np.where(cross_mask, leaders[r], leaders[target_r])
                    miracle_fit = fitness_func(miracle_pos)

                    if miracle_fit > leader_fitness[r]:
                        leaders[r] = miracle_pos
                        leader_fitness[r] = miracle_fit
                        population[r, leader_indices[r]] = miracle_pos
                        fitness[r, leader_indices[r]] = miracle_fit

            # Elitist Archive Preservation
            current_best_idx = np.argmax(leader_fitness)
            if leader_fitness[current_best_idx] > global_best_fit:
                global_best_fit = leader_fitness[current_best_idx]
                global_best_pos = leaders[current_best_idx].copy()

            convergence_curve.append(float(global_best_fit))

        return global_best_pos, float(global_best_fit), convergence_curve
