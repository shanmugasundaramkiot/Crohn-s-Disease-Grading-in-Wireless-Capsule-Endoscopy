"""85-Dimensional Directional Edge Histogram Descriptor (MPEG-7 Standard).

Partitions the image into 4x4 sub-blocks (16 sub-blocks).
Calculates mass distribution across 5 edge directions:
- Vertical (0 deg)
- Horizontal (90 deg)
- 45-degree diagonal
- 135-degree anti-diagonal
- Non-directional edge
Outputs: 16 * 5 = 80 local bins + 5 global pooled bins = 85 dimensions.
"""

import cv2
import numpy as np


class DirectionalEdgeHistogram:
    def __init__(self, grid_rows: int = 4, grid_cols: int = 4, threshold: float = 0.1):
        self.grid_rows = grid_rows
        self.grid_cols = grid_cols
        self.threshold = threshold

        # Sobel-like edge filters (2x2 normalized kernels)
        self.kernels = {
            "vert": np.array([[1.0, -1.0], [1.0, -1.0]], dtype=np.float32),
            "horiz": np.array([[1.0, 1.0], [-1.0, -1.0]], dtype=np.float32),
            "diag45": np.array([[math_sqrt2 := np.sqrt(2.0), 0.0], [0.0, -math_sqrt2]], dtype=np.float32),
            "diag135": np.array([[0.0, math_sqrt2], [-math_sqrt2, 0.0]], dtype=np.float32),
            "nondir": np.array([[2.0, -2.0], [-2.0, 2.0]], dtype=np.float32),
        }

    def compute(self, image: np.ndarray) -> np.ndarray:
        """Extracts the 85-dimensional normalized edge histogram."""
        if image.ndim == 3:
            gray = cv2.cvtColor((image * 255.0).astype(np.uint8), cv2.COLOR_RGB2GRAY).astype(np.float32) / 255.0
        else:
            gray = image.astype(np.float32)

        H, W = gray.shape
        block_h = H // self.grid_rows
        block_w = W // self.grid_cols

        # Compute edge response maps
        responses = {}
        for name, kernel in self.kernels.items():
            responses[name] = np.abs(cv2.filter2D(gray, -1, kernel))

        local_hist = []
        for r in range(self.grid_rows):
            for c in range(self.grid_cols):
                y0, y1 = r * block_h, (r + 1) * block_h
                x0, x1 = c * block_w, (c + 1) * block_w

                counts = []
                for name in ["vert", "horiz", "diag45", "diag135", "nondir"]:
                    sub_map = responses[name][y0:y1, x0:x1]
                    count = np.sum(sub_map > self.threshold)
                    counts.append(count)

                counts = np.array(counts, dtype=np.float32)
                total = np.sum(counts) + 1e-7
                norm_counts = counts / total  # Mass conservation: sum = 1
                local_hist.extend(norm_counts.tolist())

        # Global pooled 5 bins
        global_counts = []
        for name in ["vert", "horiz", "diag45", "diag135", "nondir"]:
            global_counts.append(np.sum(responses[name] > self.threshold))
        global_counts = np.array(global_counts, dtype=np.float32)
        global_counts = global_counts / (np.sum(global_counts) + 1e-7)

        descriptor = np.array(local_hist + global_counts.tolist(), dtype=np.float32)
        assert len(descriptor) == 85, f"Expected 85-D, got {len(descriptor)}"
        return descriptor
