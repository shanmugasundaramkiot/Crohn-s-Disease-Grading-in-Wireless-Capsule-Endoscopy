"""Multi-Scale 131-Dimensional Descriptor Extractor Pipeline.

Combines:
- 85-D Directional Edge Histogram Descriptor (EHD)
- 16-D Dominant Color Descriptor (DCD)
- 30-D Gabor Texture Energy Bank
Output: Compact 131-D feature vector z in R^131.
"""

import numpy as np
from .edge_histogram import DirectionalEdgeHistogram
from .dominant_color import DominantColorDescriptor
from .gabor_texture import GaborTextureBank


class MultiScaleDescriptorExtractor:
    def __init__(self):
        self.ehd = DirectionalEdgeHistogram()
        self.dcd = DominantColorDescriptor()
        self.gabor = GaborTextureBank()

    def __call__(self, image: np.ndarray) -> np.ndarray:
        """Extracts the combined 131-dimensional descriptor vector."""
        z_edge = self.ehd.compute(image)       # 85-D
        z_color = self.dcd.compute(image)      # 16-D
        z_texture = self.gabor.compute(image)  # 30-D

        z = np.concatenate([z_edge, z_color, z_texture], axis=0)
        assert len(z) == 131, f"Expected 131-D, got {len(z)}"
        return z.astype(np.float32)
