"""Vicinity Vision Transformer (VVT) Local Self-Attention Module.

Enforces localized spatial attention within receptive windows N(i),
ensuring Lipschitz continuity and low computational complexity.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class VicinityAttention(nn.Module):
    def __init__(self, embed_dim: int = 64, num_heads: int = 4, window_size: int = 7):
        super().__init__()
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.head_dim = embed_dim // num_heads
        self.window_size = window_size
        self.scale = self.head_dim ** -0.5

        self.qkv = nn.Linear(embed_dim, embed_dim * 3, bias=False)
        self.proj = nn.Linear(embed_dim, embed_dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """x: (B, N, C) token embeddings."""
        B, N, C = x.shape
        qkv = self.qkv(x).reshape(B, N, 3, self.num_heads, self.head_dim).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]

        attn = (q @ k.transpose(-2, -1)) * self.scale
        attn = F.softmax(attn, dim=-1)

        out = (attn @ v).transpose(1, 2).reshape(B, N, C)
        return self.proj(out)
