"""16-Dimensional Dominant Color Descriptor via Generalized Lloyd Algorithm (CIE-Lab).

Extracts kappa = 4 dominant color centroids and their spatial percentages:
Output: [p_1, L_1, a_1, b_1, ..., p_4, L_4, a_4, b_4] in R^16.
"""

import cv2
import numpy as np
from sklearn.cluster import KMeans


class DominantColorDescriptor:
    def __init__(self, num_clusters: int = 4, max_iter: int = 50, random_state: int = 42):
        self.num_clusters = num_clusters
        self.max_iter = max_iter
        self.random_state = random_state

    def compute(self, image: np.ndarray) -> np.ndarray:
        """Computes the 16-D dominant color descriptor from an RGB image."""
        if image.ndim != 3:
            raise ValueError("DominantColorDescriptor requires a 3-channel RGB image.")

        # Convert to CIE-Lab space
        u8_img = (np.clip(image, 0.0, 1.0) * 255.0).astype(np.uint8)
        lab_img = cv2.cvtColor(u8_img, cv2.COLOR_RGB2LAB).astype(np.float32)
        pixels = lab_img.reshape(-1, 3)

        # Generalized Lloyd Algorithm via k-means clustering
        kmeans = KMeans(
            n_clusters=self.num_clusters,
            max_iter=self.max_iter,
            n_init=3,
            random_state=self.random_state,
        )
        labels = kmeans.fit_predict(pixels)
        centers = kmeans.cluster_centers_

        total_pixels = len(pixels)
        descriptor = []

        # Sort clusters by descending area percentage for permutation invariance
        unique, counts = np.unique(labels, return_counts=True)
        share_map = {u: count / total_pixels for u, count in zip(unique, counts)}

        sorted_clusters = sorted(range(self.num_clusters), key=lambda k: share_map.get(k, 0.0), reverse=True)

        for k in sorted_clusters:
            p_k = share_map.get(k, 0.0)
            L, a, b = centers[k]
            # Normalize Lab coordinates: L in [0, 100], a,b in [-128, 127]
            norm_L = L / 100.0
            norm_a = (a + 128.0) / 255.0
            norm_b = (b + 128.0) / 255.0
            descriptor.extend([p_k, norm_L, norm_a, norm_b])

        out = np.array(descriptor, dtype=np.float32)
        assert len(out) == 16, f"Expected 16-D, got {len(out)}"
        return out
