"""30-Dimensional Multi-Scale Gabor Texture Filter Bank.

Computes texture energy response across:
- 5 spatial frequencies
- 6 orientations (0, 30, 60, 90, 120, 150 deg)
Outputs: Mean energy and standard deviation for each response = 30 dimensions.
"""

import cv2
import numpy as np


class GaborTextureBank:
    def __init__(self, num_scales: int = 5, num_orientations: int = 6):
        self.num_scales = num_scales
        self.num_orientations = num_orientations
        self.filters = self._build_filters()

    def _build_filters(self):
        filters = []
        ksize = 15
        sigma = 3.0
        gamma = 0.5
        psi = 0.0

        for s in range(self.num_scales):
            lambd = 3.0 * (1.5 ** s)  # Wavelength
            for o in range(self.num_orientations):
                theta = o * np.pi / self.num_orientations
                kern = cv2.getGaborKernel((ksize, ksize), sigma, theta, lambd, gamma, psi, ktype=cv2.CV_32F)
                filters.append(kern)
        return filters

    def compute(self, image: np.ndarray) -> np.ndarray:
        """Extracts the 30-D Gabor texture energy vector."""
        if image.ndim == 3:
            gray = cv2.cvtColor((image * 255.0).astype(np.uint8), cv2.COLOR_RGB2GRAY).astype(np.float32) / 255.0
        else:
            gray = image.astype(np.float32)

        descriptor = []
        for kern in self.filters:
            fimg = cv2.filter2D(gray, cv2.CV_32F, kern)
            mean_energy = float(np.mean(np.abs(fimg)))
            std_energy = float(np.std(fimg))
            descriptor.append(mean_energy)

        out = np.array(descriptor, dtype=np.float32)
        # Normalize across the vector
        norm = np.linalg.norm(out) + 1e-7
        out = out / norm
        assert len(out) == 30, f"Expected 30-D, got {len(out)}"
        return out
