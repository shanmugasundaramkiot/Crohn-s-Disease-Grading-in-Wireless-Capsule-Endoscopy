"""BF-VVT-SMCNN-DRA: Automated Crohn's Disease Grading in Wireless Capsule Endoscopy."""
__version__ = "1.0.0"
