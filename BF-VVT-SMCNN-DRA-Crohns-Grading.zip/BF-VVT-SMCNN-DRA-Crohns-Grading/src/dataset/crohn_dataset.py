"""CrohnIPI Dataset Loader for Wireless Capsule Endoscopy.

Supports:
- 7 Diagnostic categories: Normal (N), Erythema (E), Edema (O),
  Aphthoid Ulceration (AU), Ulceration 3-10mm (U3-10), Stenosis (S),
  Ulceration >10mm (U>10).
- 5-Fold cross-validation splits directly from CrohnIPI_description.csv.
- Precomputed or on-the-fly Bellman filtering and 131-D descriptor extraction.
"""

import os
import cv2
import pandas as pd
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader
from typing import Optional, Callable

LABEL_MAP = {
    "N": 0,
    "E": 1,
    "O": 2,
    "AU": 3,
    "U3-10": 4,
    "S": 5,
    "U>10": 6,
}

CLASS_NAMES = [
    "Normal",
    "Erythema",
    "Edema",
    "Aphthoid ulceration",
    "U3-10",
    "Stenosis",
    "U>10",
]


class CrohnIPIDataset(Dataset):
    def __init__(
        self,
        data_dir: str,
        csv_file: str,
        fold: Optional[int] = None,
        is_train: bool = True,
        img_size: tuple = (224, 224),
        bellman_filter: Optional[Callable] = None,
        descriptor_extractor: Optional[Callable] = None,
        augmenter: Optional[Callable] = None,
    ):
        self.data_dir = data_dir
        self.imgs_dir = os.path.join(data_dir, "imgs")
        self.img_size = img_size
        self.bellman_filter = bellman_filter
        self.descriptor_extractor = descriptor_extractor
        self.augmenter = augmenter

        # Read CSV
        csv_path = os.path.join(data_dir, csv_file) if not os.path.isabs(csv_file) else csv_file
        df = pd.read_csv(csv_path)

        # Standardize column names
        df.columns = [c.strip() for c in df.columns]
        frame_col = df.columns[0]
        label_col = df.columns[1]
        fold_col = df.columns[2]

        if fold is not None:
            if is_train:
                self.df = df[df[fold_col] != fold].reset_index(drop=True)
            else:
                self.df = df[df[fold_col] == fold].reset_index(drop=True)
        else:
            self.df = df.reset_index(drop=True)

        self.frame_col = frame_col
        self.label_col = label_col

    def __len__(self) -> int:
        return len(self.df)

    def __getitem__(self, idx: int):
        row = self.df.iloc[idx]
        frame_name = str(row[self.frame_col]).strip()
        label_str = str(row[self.label_col]).strip()
        label_idx = LABEL_MAP.get(label_str, 0)

        img_path = os.path.join(self.imgs_dir, frame_name)
        img_bgr = cv2.imread(img_path)

        if img_bgr is None:
            # Fallback black image if file not found
            img_rgb = np.zeros((self.img_size[0], self.img_size[1], 3), dtype=np.float32)
        else:
            img_rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
            if img_rgb.shape[:2] != self.img_size:
                img_rgb = cv2.resize(img_rgb, self.img_size, interpolation=cv2.INTER_LINEAR)

        # Apply augmentation if training
        if self.augmenter is not None:
            img_rgb = self.augmenter(img_rgb)

        # Stage I: Edge-Adaptive Bellman Filtering
        if self.bellman_filter is not None:
            proc_img = self.bellman_filter(img_rgb)
        else:
            proc_img = img_rgb

        # Stage II: Multi-Scale Descriptor Extraction
        if self.descriptor_extractor is not None:
            descriptor = self.descriptor_extractor(proc_img)
        else:
            descriptor = np.zeros(131, dtype=np.float32)

        # PyTorch channel-first tensor (3, H, W)
        tensor_img = torch.from_numpy(proc_img.transpose(2, 0, 1)).float()
        tensor_desc = torch.from_numpy(descriptor).float()
        tensor_label = torch.tensor(label_idx, dtype=torch.long)

        return tensor_img, tensor_desc, tensor_label


def get_dataloaders(
    data_dir: str,
    csv_file: str = "CrohnIPI_description.csv",
    fold: int = 1,
    batch_size: int = 32,
    bellman_filter=None,
    descriptor_extractor=None,
    num_workers: int = 0,
):
    train_dataset = CrohnIPIDataset(
        data_dir=data_dir,
        csv_file=csv_file,
        fold=fold,
        is_train=True,
        bellman_filter=bellman_filter,
        descriptor_extractor=descriptor_extractor,
    )
    val_dataset = CrohnIPIDataset(
        data_dir=data_dir,
        csv_file=csv_file,
        fold=fold,
        is_train=False,
        bellman_filter=bellman_filter,
        descriptor_extractor=descriptor_extractor,
    )

    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=num_workers)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False, num_workers=num_workers)

    return train_loader, val_loader
