"""Endoscopic Image Augmentation Protocol."""

import cv2
import numpy as np


class EndoscopicAugmenter:
    def __init__(self, prob_flip: float = 0.5, prob_rotate: float = 0.5, max_angle: float = 20.0):
        self.prob_flip = prob_flip
        self.prob_rotate = prob_rotate
        self.max_angle = max_angle

    def __call__(self, img: np.ndarray) -> np.ndarray:
        out = img.copy()

        # Random horizontal flip
        if np.random.rand() < self.prob_flip:
            out = np.fliplr(out)

        # Random vertical flip
        if np.random.rand() < self.prob_flip:
            out = np.flipud(out)

        # Random rotation within +/- max_angle
        if np.random.rand() < self.prob_rotate:
            angle = np.random.uniform(-self.max_angle, self.max_angle)
            h, w = out.shape[:2]
            M = cv2.getRotationMatrix2D((w / 2, h / 2), angle, 1.0)
            out = cv2.warpAffine(out, M, (w, h), borderMode=cv2.BORDER_REFLECT)

        # Subtle chromatic jitter
        if np.random.rand() < 0.3:
            jitter = np.random.uniform(0.9, 1.1, size=(1, 1, 3)).astype(np.float32)
            out = np.clip(out * jitter, 0.0, 1.0)

        return out
