"""Statistical Hypothesis Testing: One-Way ANOVA and Welch's t-test."""

import numpy as np
from scipy import stats


def one_way_anova(*groups) -> dict:
    """Performs one-way ANOVA across G configuration groups.
    
    Returns:
        SSB, SSW, MSB, MSW, F_stat, p_value
    """
    all_data = [np.asarray(g, dtype=np.float64) for g in groups]
    G = len(all_data)
    N = sum(len(g) for g in all_data)
    grand_mean = np.mean(np.concatenate(all_data))

    ssb = sum(len(g) * (np.mean(g) - grand_mean) ** 2 for g in all_data)
    ssw = sum(np.sum((g - np.mean(g)) ** 2) for g in all_data)
    df_b = G - 1
    df_w = N - G

    msb = ssb / df_b
    msw = ssw / df_w
    f_stat = msb / msw
    p_value = float(stats.f.sf(f_stat, df_b, df_w))

    return {
        "ss_between": float(ssb),
        "ss_within": float(ssw),
        "df_between": int(df_b),
        "df_within": int(df_w),
        "ms_between": float(msb),
        "ms_within": float(msw),
        "f_statistic": float(f_stat),
        "p_value": p_value,
    }


def welch_ttest(g1: np.ndarray, g2: np.ndarray) -> dict:
    """Performs Welch's two-sample t-test (unequal variances assumed)."""
    a = np.asarray(g1, dtype=np.float64)
    b = np.asarray(g2, dtype=np.float64)

    res = stats.ttest_ind(a, b, equal_var=False)

    # Cohen's d effect size
    s1, s2 = np.var(a, ddof=1), np.var(b, ddof=1)
    n1, n2 = len(a), len(b)
    s_pooled = np.sqrt(((n1 - 1) * s1 + (n2 - 1) * s2) / (n1 + n2 - 2))
    cohen_d = float((np.mean(a) - np.mean(b)) / (s_pooled + 1e-8))

    return {
        "t_statistic": float(res.statistic),
        "p_value": float(res.pvalue),
        "cohen_d": cohen_d,
    }
