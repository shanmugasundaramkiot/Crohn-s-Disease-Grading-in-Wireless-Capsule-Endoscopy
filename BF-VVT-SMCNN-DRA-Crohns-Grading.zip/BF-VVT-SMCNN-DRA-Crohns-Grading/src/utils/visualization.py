"""Plotting and Visualization Utilities."""

import matplotlib.pyplot as plt
import numpy as np


def plot_confusion_matrix(cm: np.ndarray, class_names: list, save_path: str = None):
    fig, ax = plt.subplots(figsize=(7, 6))
    im = ax.imshow(cm, interpolation="nearest", cmap=plt.cm.Blues)
    ax.figure.colorbar(im, ax=ax)

    ax.set(
        xticks=np.arange(cm.shape[1]),
        yticks=np.arange(cm.shape[0]),
        xticklabels=class_names,
        yticklabels=class_names,
        title="Confusion Matrix",
        ylabel="True Diagnosis",
        xlabel="Predicted Diagnosis",
    )
    plt.setp(ax.get_xticklabels(), rotation=45, ha="right", rotation_mode="anchor")

    thresh = cm.max() / 2.0
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            ax.text(j, i, format(cm[i, j], "d"), ha="center", va="center",
                    color="white" if cm[i, j] > thresh else "black")

    fig.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=300)
    plt.close()


def plot_roc_curves(fpr_dict: dict, tpr_dict: dict, roc_auc: dict, class_names: list, save_path: str = None):
    plt.figure(figsize=(8, 6))
    for i, name in enumerate(class_names):
        if i in fpr_dict:
            plt.plot(fpr_dict[i], tpr_dict[i], label=f"{name} (AUC = {roc_auc[i]:.3f})")

    plt.plot([0, 1], [0, 1], "k--", lw=1.5)
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("Receiver Operating Characteristic (ROC)")
    plt.legend(loc="lower right")
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=300)
    plt.close()


def plot_convergence(train_acc: list, val_acc: list, train_loss: list, val_loss: list, save_path: str = None):
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))

    ax1.plot(train_acc, label="Train Accuracy")
    ax1.plot(val_acc, label="Validation Accuracy")
    ax1.set_xlabel("Epoch")
    ax1.set_ylabel("Accuracy")
    ax1.set_title("Training and Validation Accuracy")
    ax1.legend()
    ax1.grid(True)

    ax2.plot(train_loss, label="Train Loss")
    ax2.plot(val_loss, label="Validation Loss")
    ax2.set_xlabel("Epoch")
    ax2.set_ylabel("Cross-Entropy Loss")
    ax2.set_title("Training and Validation Loss")
    ax2.legend()
    ax2.grid(True)

    fig.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=300)
    plt.close()
