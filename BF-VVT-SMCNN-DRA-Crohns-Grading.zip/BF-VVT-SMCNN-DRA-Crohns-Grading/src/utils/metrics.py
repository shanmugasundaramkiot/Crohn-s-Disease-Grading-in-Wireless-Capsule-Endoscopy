"""Evaluation Metrics for Denoising and Multi-Class Classification."""

import numpy as np
from skimage.metrics import peak_signal_noise_ratio, structural_similarity
from sklearn.metrics import (
    accuracy_score,
    precision_recall_fscore_support,
    roc_auc_score,
    cohen_kappa_score,
    matthews_corrcoef,
    confusion_matrix,
)


def compute_denoising_metrics(clean: np.ndarray, denoised: np.ndarray) -> dict:
    """Computes PSNR and SSIM between clean reference and denoised image."""
    c = np.clip(clean, 0.0, 1.0)
    d = np.clip(denoised, 0.0, 1.0)

    psnr_val = peak_signal_noise_ratio(c, d, data_range=1.0)
    ssim_val = structural_similarity(c, d, data_range=1.0, channel_axis=-1 if c.ndim == 3 else None)
    mse_val = float(np.mean((c - d) ** 2))

    return {
        "psnr": float(psnr_val),
        "ssim": float(ssim_val),
        "mse": mse_val,
    }


def compute_classification_metrics(y_true: np.ndarray, y_pred: np.ndarray, y_prob: np.ndarray = None) -> dict:
    """Computes comprehensive multi-class classification metrics."""
    acc = accuracy_score(y_true, y_pred)
    macro_p, macro_r, macro_f1, _ = precision_recall_fscore_support(y_true, y_pred, average="macro", zero_division=0)
    micro_p, micro_r, micro_f1, _ = precision_recall_fscore_support(y_true, y_pred, average="micro", zero_division=0)

    # Per-class metrics
    class_p, class_r, class_f1, _ = precision_recall_fscore_support(y_true, y_pred, average=None, zero_division=0)

    kappa = cohen_kappa_score(y_true, y_pred)
    mcc = matthews_corrcoef(y_true, y_pred)
    cm = confusion_matrix(y_true, y_pred)

    out = {
        "accuracy": float(acc),
        "macro_precision": float(macro_p),
        "macro_recall": float(macro_r),
        "macro_f1": float(macro_f1),
        "micro_precision": float(micro_p),
        "micro_recall": float(micro_r),
        "micro_f1": float(micro_f1),
        "cohen_kappa": float(kappa),
        "mcc": float(mcc),
        "per_class_precision": class_p.tolist(),
        "per_class_recall": class_r.tolist(),
        "per_class_f1": class_f1.tolist(),
        "confusion_matrix": cm.tolist(),
    }

    if y_prob is not None:
        try:
            auc = roc_auc_score(y_true, y_prob, multi_class="ovr", average="macro")
            out["macro_auc"] = float(auc)
        except Exception:
            out["macro_auc"] = None

    return out
