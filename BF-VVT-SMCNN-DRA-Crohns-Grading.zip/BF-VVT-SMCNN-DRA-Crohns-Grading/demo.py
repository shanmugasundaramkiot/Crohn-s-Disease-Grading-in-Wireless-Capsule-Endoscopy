"""Quickstart Demonstration Script: End-to-End WCE Lesion Grading.

Executes:
1. Edge-Adaptive Bellman Filtering on a sample capsule image
2. 131-D Multi-Scale Descriptor Extraction (EHD + DCD + Gabor)
3. Self-Modulating CNN (SMCNN) forward inference
4. Diagnostic grade prediction and execution latency report
"""

import time
import numpy as np
import torch

from src.filtering.bellman_filter import EdgeAdaptiveBellmanFilter
from src.descriptors.feature_pipeline import MultiScaleDescriptorExtractor
from src.models.smcnn import SelfModulatingCNN
from src.dataset.crohn_dataset import CLASS_NAMES


def main():
    print("=" * 70)
    print("QUICKSTART DEMO: BF-VVT-SMCNN-DRA FOR CROHN'S LESION GRADING")
    print("=" * 70)

    # 1. Create a simulated endoscopic image (224x224x3)
    np.random.seed(123)
    img_sample = np.random.uniform(0.3, 0.8, size=(224, 224, 3)).astype(np.float32)

    # 2. Stage I: Edge-Adaptive Bellman Recursive Filter
    print("\n[Stage I] Running Edge-Adaptive Bellman Filter...")
    t0 = time.perf_counter()
    filter_obj = EdgeAdaptiveBellmanFilter(Q0=0.006, R=0.0025, sigma_s=0.30)
    filtered_img = filter_obj(img_sample)
    t_stage1 = (time.perf_counter() - t0) * 1000.0
    print(f"  -> Stage I completed in {t_stage1:.2f} ms")

    # 3. Stage II: 131-D Descriptor Extraction
    print("\n[Stage II] Extracting 131-D Multi-Scale Descriptors...")
    t0 = time.perf_counter()
    extractor = MultiScaleDescriptorExtractor()
    descriptor = extractor(filtered_img)
    t_stage2 = (time.perf_counter() - t0) * 1000.0
    print(f"  -> Extracted descriptor of shape: {descriptor.shape}")
    print(f"  -> Stage II completed in {t_stage2:.2f} ms")

    # 4. Stage III: SMCNN Inference
    print("\n[Stage III] Executing SMCNN Forward Inference...")
    t0 = time.perf_counter()
    model = SelfModulatingCNN(num_classes=7, descriptor_dim=131, hidden_dim=64)
    model.eval()

    tensor_img = torch.from_numpy(filtered_img.transpose(2, 0, 1)).unsqueeze(0).float()
    tensor_desc = torch.from_numpy(descriptor).unsqueeze(0).float()

    with torch.no_grad():
        logits = model(tensor_img, tensor_desc)
        probs = torch.softmax(logits, dim=1).numpy()[0]
    t_stage3 = (time.perf_counter() - t0) * 1000.0
    print(f"  -> Stage III completed in {t_stage3:.2f} ms")

    total_latency = t_stage1 + t_stage2 + t_stage3
    pred_idx = int(np.argmax(probs))
    pred_class = CLASS_NAMES[pred_idx]
    confidence = float(probs[pred_idx]) * 100.0

    print("\n" + "=" * 70)
    print("DIAGNOSTIC PREDICTION RESULTS:")
    print(f"  Predicted Category: {pred_class} (Class ID: {pred_idx})")
    print(f"  Confidence:         {confidence:.2f}%")
    print(f"  End-to-End Latency: {total_latency:.2f} ms (>50 FPS throughput)")
    print("=" * 70)
    print("Demo completed successfully!")


if __name__ == "__main__":
    main()
