"""Statistical Hypothesis Testing: ANOVA and Welch's t-test (Reproducing Tables 7, 8)."""

import sys
import os
import numpy as np

# Add repo root to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.utils.statistical_tests import one_way_anova, welch_ttest


def main():
    print("=" * 70)
    print("STATISTICAL HYPOTHESIS TESTING: ONE-WAY ANOVA & WELCH'S T-TEST")
    print("=" * 70)

    # 5 folds each across 4 configurations
    g_d = np.array([0.582, 0.614, 0.593, 0.648, 0.558])  # Config d
    g_c = np.array([0.751, 0.772, 0.785, 0.758, 0.774])  # Config c
    g_b = np.array([0.842, 0.811, 0.884, 0.852, 0.791])  # Config b
    g_a = np.array([0.838, 0.824, 0.871, 0.845, 0.772])  # Config a

    # One-way ANOVA
    anova_res = one_way_anova(g_d, g_c, g_b, g_a)
    print("One-Way ANOVA Decomposition (Table 7):")
    print(f"Between-Groups SS: {anova_res['ss_between']:.4f} (df = {anova_res['df_between']})")
    print(f"Within-Groups SS:  {anova_res['ss_within']:.4f} (df = {anova_res['df_within']})")
    print(f"MS Between:        {anova_res['ms_between']:.4f}")
    print(f"MS Within:         {anova_res['ms_within']:.5f}")
    print(f"F-Statistic:       {anova_res['f_statistic']:.2f}")
    print(f"p-Value:           {anova_res['p_value']:.2e}")

    # Pairwise Welch t-tests
    print("\nPairwise Welch Two-Sample t-Tests (Table 8):")
    comps = [
        ("(d) colour-only vs. (c) w/o BF", g_d, g_c),
        ("(c) w/o BF vs. (b) w/o DRA", g_c, g_b),
        ("(b) w/o DRA vs. (a) Full Pipeline", g_b, g_a),
        ("(d) colour-only vs. (a) Full Pipeline", g_d, g_a),
    ]

    print(f"{'Comparison':<40} | {'Welch t':<10} | {'p-Value':<12} | {'Cohen d'}")
    print("-" * 75)
    for name, c1, c2 in comps:
        t_res = welch_ttest(c1, c2)
        print(f"{name:<40} | {t_res['t_statistic']:>8.2f} | {t_res['p_value']:>10.5f} | {t_res['cohen_d']:>8.2f}")
    print("=" * 70)


if __name__ == "__main__":
    main()
