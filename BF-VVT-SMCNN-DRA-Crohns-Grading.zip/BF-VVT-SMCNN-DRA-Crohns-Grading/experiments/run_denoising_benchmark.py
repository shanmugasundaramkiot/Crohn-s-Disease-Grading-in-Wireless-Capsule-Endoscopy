"""Denoising Benchmark Experiment (Reproducing Table 1 and Figure 2).

Evaluates Edge-Adaptive Bellman Filtering vs. Bilateral Baseline on corrupted endoscopic frames.
"""

import sys
import os
import time
import numpy as np

# Add repo root to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.filtering.bellman_filter import EdgeAdaptiveBellmanFilter
from src.filtering.baseline_filters import BilateralFilter, GaussianFilter
from src.utils.metrics import compute_denoising_metrics


def main():
    print("=" * 70)
    print("RUNNING STAGE I: DENOISING BENCHMARK EXPERIMENT")
    print("=" * 70)

    # Synthetic mucosal texture image for demonstration
    np.random.seed(42)
    H, W = 224, 224

    # Generate synthetic mucosa with smooth vascular curves and edges
    x, y = np.meshgrid(np.linspace(0, 1, W), np.linspace(0, 1, H))
    clean_ref = np.zeros((H, W, 3), dtype=np.float32)
    clean_ref[:, :, 0] = 0.7 + 0.15 * np.sin(4 * np.pi * x)  # Erythema red channel
    clean_ref[:, :, 1] = 0.3 + 0.10 * np.cos(4 * np.pi * y)  # Green channel
    clean_ref[:, :, 2] = 0.2 + 0.05 * np.sin(2 * np.pi * (x + y))  # Blue channel
    # Add mucosal fold step-edge
    clean_ref[H // 2 :, :, :] -= 0.15
    clean_ref = np.clip(clean_ref, 0.0, 1.0)

    # Add Gaussian sensor noise (R = 0.0025 -> sigma = 0.05)
    noise = np.random.normal(0, 0.062, clean_ref.shape).astype(np.float32)
    noisy_input = np.clip(clean_ref + noise, 0.0, 1.0)

    # Initial metrics
    m_noisy = compute_denoising_metrics(clean_ref, noisy_input)
    print(f"Corrupted Input   : PSNR = {m_noisy['psnr']:.2f} dB, SSIM = {m_noisy['ssim']:.4f}, MSE = {m_noisy['mse']:.5f}")

    # Bilateral Baseline
    bilateral = BilateralFilter(d=9, sigma_color=75.0, sigma_space=75.0)
    t0 = time.perf_counter()
    denoised_bilateral = bilateral(noisy_input)
    t_bilateral = (time.perf_counter() - t0) * 1000.0
    m_bilateral = compute_denoising_metrics(clean_ref, denoised_bilateral)
    print(f"Bilateral Baseline: PSNR = {m_bilateral['psnr']:.2f} dB, SSIM = {m_bilateral['ssim']:.4f}, Latency = {t_bilateral:.2f} ms")

    # Proposed Edge-Adaptive Bellman Filter
    bellman = EdgeAdaptiveBellmanFilter(Q0=0.006, R=0.0025, sigma_s=0.30, epsilon=1e-5)
    t0 = time.perf_counter()
    denoised_bellman = bellman(noisy_input)
    t_bellman = (time.perf_counter() - t0) * 1000.0
    m_bellman = compute_denoising_metrics(clean_ref, denoised_bellman)
    print(f"Proposed Bellman  : PSNR = {m_bellman['psnr']:.2f} dB, SSIM = {m_bellman['ssim']:.4f}, Latency = {t_bellman:.2f} ms")

    print("-" * 70)
    print(f"Quantitative PSNR Gain over Input:     +{m_bellman['psnr'] - m_noisy['psnr']:.2f} dB")
    print(f"Quantitative PSNR Gain over Bilateral: +{m_bellman['psnr'] - m_bilateral['psnr']:.2f} dB")
    print(f"Latency Reduction vs. Bilateral:       {(1 - t_bellman / t_bilateral) * 100:.1f}%")
    print("=" * 70)


if __name__ == "__main__":
    main()
